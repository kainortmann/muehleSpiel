package muehle;

public class Figure {
    private MuehleColor color;

    public MuehleColor getColor() {
        return color;
    }
}
