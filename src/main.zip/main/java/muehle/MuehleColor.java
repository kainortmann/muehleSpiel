package muehle;

public enum MuehleColor {
    BLACK,WHITE
}
