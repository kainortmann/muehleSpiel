package muehle;

import muehle.PositionEnums.RectanglePosition;
import muehle.PositionEnums.XPosition;
import muehle.PositionEnums.YPosition;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static muehle.PositionEnums.XPosition.LEFT;
import static muehle.PositionEnums.XPosition.MIDDLE;
import static muehle.PositionEnums.XPosition.RIGHT;
import static muehle.PositionEnums.YPosition.BOTTOM;
import static muehle.PositionEnums.YPosition.TOP;

public class Board {
    private static Board ourInstance = new Board();
    private List<Field> allFields;

    public static Board getInstance() {
        return ourInstance;
    }

    private Board() {
        allFields = new ArrayList<>();
        allFields.add(new Field(RectanglePosition.OUTSIDE, LEFT, TOP));
        allFields.add(new Field(RectanglePosition.OUTSIDE, XPosition.MIDDLE, TOP));
        allFields.add(new Field(RectanglePosition.OUTSIDE, RIGHT, TOP));
        allFields.add(new Field(RectanglePosition.OUTSIDE, LEFT, BOTTOM));
        allFields.add(new Field(RectanglePosition.OUTSIDE, MIDDLE, BOTTOM));
        allFields.add(new Field(RectanglePosition.OUTSIDE, RIGHT, BOTTOM));
        allFields.add(new Field(RectanglePosition.OUTSIDE, LEFT, YPosition.MIDDLE));
        allFields.add(new Field(RectanglePosition.OUTSIDE, RIGHT, YPosition.MIDDLE));

        allFields.add(new Field(RectanglePosition.MIDDLE, LEFT, TOP));
        allFields.add(new Field(RectanglePosition.MIDDLE, MIDDLE, TOP));
        allFields.add(new Field(RectanglePosition.MIDDLE, RIGHT, TOP));
        allFields.add(new Field(RectanglePosition.MIDDLE, LEFT, BOTTOM));
        allFields.add(new Field(RectanglePosition.MIDDLE, MIDDLE, BOTTOM));
        allFields.add(new Field(RectanglePosition.MIDDLE, RIGHT, BOTTOM));
        allFields.add(new Field(RectanglePosition.MIDDLE, LEFT, YPosition.MIDDLE));
        allFields.add(new Field(RectanglePosition.MIDDLE, RIGHT, YPosition.MIDDLE));

        allFields.add(new Field(RectanglePosition.INSIDE, LEFT, TOP));
        allFields.add(new Field(RectanglePosition.INSIDE, MIDDLE, TOP));
        allFields.add(new Field(RectanglePosition.INSIDE, RIGHT, TOP));
        allFields.add(new Field(RectanglePosition.INSIDE, LEFT, BOTTOM));
        allFields.add(new Field(RectanglePosition.INSIDE, MIDDLE, BOTTOM));
        allFields.add(new Field(RectanglePosition.INSIDE, RIGHT, BOTTOM));
        allFields.add(new Field(RectanglePosition.INSIDE, LEFT, YPosition.MIDDLE));
        allFields.add(new Field(RectanglePosition.INSIDE, RIGHT, YPosition.MIDDLE));
    }

    public List<Field> getAllFields() {
        return allFields;
    }
}
