package muehle.PositionEnums;

public enum YPosition {
    TOP,MIDDLE,BOTTOM
}
