package muehle.PositionEnums;

public enum XPosition {
    LEFT,MIDDLE,RIGHT
}
