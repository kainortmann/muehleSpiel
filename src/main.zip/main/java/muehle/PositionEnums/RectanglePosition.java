package muehle.PositionEnums;

public enum RectanglePosition {
    OUTSIDE,MIDDLE,INSIDE

    }
