package muehle;

import muehle.PositionEnums.RectanglePosition;

import javax.swing.text.Position;
import java.util.ArrayList;
import java.util.List;

public class Util {

    public static void getNeigbours(Position field){
        RectanglePosition[] rectangleNeighbours = {RectanglePosition.INSIDE, RectanglePosition.MIDDLE, RectanglePosition.OUTSIDE};

        String rectanglePosiotion;
        String xPosition;
        String yPosition;


    }


    public static List<Field> getMoveOptions(Field field){
        List<Field> possibleOptions = new ArrayList<>();
        final Integer myY;
        for (Field boardField : Board.getInstance().getAllFields()){
            int boardFieldX = boardField.getXPositionOnImaginaryGrid();
            int boardFieldY = boardField.getYPositionOnImaginaryGrid();

        }
        for (int x=-1; x<=1; x++) {
            if( (field.getXPositionOnImaginaryGrid() + x)>=0 && (field.getXPositionOnImaginaryGrid() + x)<=6){
                for (int y = -1; y<= 1; y ++) {
                    if( (field.getYPositionOnImaginaryGrid() + y)>=0 && (field.getYPositionOnImaginaryGrid() + y)<=6) {
                        if ((Math.abs(x) == 1 || (Math.abs(y) == 1)) && !(Math.abs(x) == 1 && Math.abs(y) == 1)) {
                            if((x==-1) && (y==0)){
                                System.out.println("da");
                            }
                            if((x==-1) && (y==0)){
                                System.out.println("da");
                            }
                            if((x==-1) && (y==0)){
                                System.out.println("da");
                            }
                            if((x==-1) && (y==0)){
                                System.out.println("da");
                            }
                            for (Field boardField : Board.getInstance().getAllFields()) {
                                if(boardField.getYPositionOnImaginaryGrid() == 1){
                                    if(boardField.getXPositionOnImaginaryGrid() == 3) {
                                        if (x == 0 && y==-1){
                                            System.out.println("test");
                                        }
                                    }
                                }
                                if ((boardField.getXPositionOnImaginaryGrid() == field.getXPositionOnImaginaryGrid() + x) && (boardField.getYPositionOnImaginaryGrid() == field.getYPositionOnImaginaryGrid() + y)) {//if the field with coordinates (x,y) actually exists
                                    if (boardField.isEmpty()) {
                                        //options.add(boardField); //add it to the neighbour list
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return possibleOptions;
    }

}
