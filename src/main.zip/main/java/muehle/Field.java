package muehle;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import muehle.PositionEnums.RectanglePosition;
import muehle.PositionEnums.XPosition;
import muehle.PositionEnums.YPosition;

public class Field extends ImageView {
    private int xPositionOnImaginaryGrid;
    private int yPositionOnImaginaryGrid;
    XPosition xPosition;
    YPosition yPosition;
    Figure figure;

    RectanglePosition parentRectangle;

    public Field(RectanglePosition rectanglePosition, XPosition xPosition, YPosition yPosition) {
        super();
        this.xPositionOnImaginaryGrid = rectanglePosition.ordinal()+(3-rectanglePosition.ordinal())*xPosition.ordinal();
        this.yPositionOnImaginaryGrid = rectanglePosition.ordinal()+(3-rectanglePosition.ordinal())*yPosition.ordinal();
        this.xPosition = xPosition;
        this.yPosition = yPosition;
        this.parentRectangle = rectanglePosition;
        System.out.println("Field : x=" + xPositionOnImaginaryGrid +" y=" + yPositionOnImaginaryGrid);
    }

    public Field(RectanglePosition rectanglePosition, XPosition xPosition, YPosition yPosition, String imgURL) {
        super(imgURL);
        this.xPositionOnImaginaryGrid = rectanglePosition.ordinal()+(3-rectanglePosition.ordinal())*xPosition.ordinal();
        this.yPositionOnImaginaryGrid = rectanglePosition.ordinal()+(3-rectanglePosition.ordinal())*yPosition.ordinal();
        this.xPosition = xPosition;
        this.yPosition = yPosition;
        this.parentRectangle = rectanglePosition;
    }

    public int getXPositionOnImaginaryGrid() {
        return xPositionOnImaginaryGrid;
    }

    public int getYPositionOnImaginaryGrid() {
        return yPositionOnImaginaryGrid;
    }

    public RectanglePosition getParentRectangle() {
        return parentRectangle;
    }

    public void setFigure(Figure figure){
        if(figure == null){
            this.setImage(null);
        }
        else {
            Image fieldImage = new Image (this.getClass().getResource((figure.getColor() == MuehleColor.BLACK) ? "dame_schwarz" : "dame_weiss").toString());
        }
    }
    public void removeFigure(){
        if(figure == null){
            this.setImage(null);
        }
        else {
            Image fieldImage = new Image (this.getClass().getResource((figure.getColor() == MuehleColor.BLACK) ? "dame_schwarz" : "dame_weiss").toString());
        }
    }


    public boolean isEmpty() {
        return this.getImage() == null;
    }

    public XPosition getXPosition() {
        return xPosition;
    }

    public YPosition getYPosition() {
        return yPosition;
    }
}
